
module.exports = {
    consumer_key: 'Biu32DRjBc8OOx1Q9msToslVQ',  
    consumer_secret: 'nVeTlVaK9ZCXYYTUMqfK619LlKjha8ZBuzOCGpIkUBzRumjVv9',
    access_token: '196755353-Hrqc01VT2kLU4HZoum5lZfLifX2nGerw0RdIGOD7',  
    access_token_secret: 'ns3kVNwUNgS80vGxJSbyoo4f0WNmCVSUv5JQieHYyvaNL',
    timeout_ms: 60*1000,
    strictSSL: true, 
  }